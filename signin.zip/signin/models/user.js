var bcrypt = require('bcryptjs');
var validator = require('../public/javascripts/validator.js');
var debug = require('debug')('signin:user.js');
var _ = require('lodash');
var urlTool=require('url');
var querystring=require('querystring');
module.exports = function (db) {
    var users = db.collection('users');
    return{
        findUser:function (username, password) {
            return users.findOne({username:username}).then(function (user) {
                return user? bcrypt.compare(password,user.password).then(function (isMatch) {
                    var r = [isMatch,user];
                    return r;
                }):Promise.reject("user doesn't exit");
            });
        },
        createUser:function (user) {
            var iteration = 10;
            return bcrypt.hash(user.password,iteration).then(function (value) {
                user.password = value;
                user.repeat_password=value;
                return users.insert(user);
            });
        },
        checkUser: function (user) {
            var formatErrors = validator.findFormatErrors(user);
            console.log(user);
            return new Promise(function (reslove,reject) {
                formatErrors ? reject(formatErrors):reslove(user);
            }).then(function () {
                return users.findOne(getQueryForUniqueInAttribute(user)).then(function (value) {
                    debug("existed user: ",value);
                    return value? Promise.reject("user existed"):Promise.resolve(user);
                });
            });
        },
        //分析用户名
        parseUsername:function (request){
            return querystring.parse(urlTool.parse(request.url).query).username;
        }
    };
};

function getQueryForUniqueInAttribute(user) {
    var z = [];
    for(var key in user){
        var r = {};
        if(key!=='password'&&key!=='repeat_password'){
            r[key] = user[key];
            z[z.length] = r;
        }

    }
    return{
        $or: z
    }
}

