// 19335040 丁维力
var express = require('express');
var router = express.Router();
var debug = require('debug')('signin:index.js');
var validator =require('../public/javascripts/validator.js');
var the_user;
var quit=false;
module.exports = function(db){
    /* GET home page. */
    var users=db.collection('users');
    debug("users collection setup as:",users);
    var userManager = require('../models/user.js')(db);

    router.get('/regist', function (req, res, next) {
        res.render('signup', {title: '注册'});
    });
    router.post('/regist', function (req, res, next) {
        var user = req.body;
        userManager.checkUser(user)
        .then(userManager.createUser)
        .then(function(){
          req.session.user=user;
          the_user=user;
          res.redirect('/detail');
        })
        .catch(function(error){
          if(error.message)res.render('signup',{ title: '注册' ,error:error.message});
          else res.render('signup',{ title: '注册' ,error:error});
        });
    });


    router.get('/signout', function (req, res, next) {
        delete req.session.user;
        req.session.user=null;
        the_user=null;
        quit=true;
        res.redirect('/signin');
    });
    router.get('/signin', function (req, res, next) {
        if(quit)req.session.user=the_user;
        quit=false;
        res.render('signin', {title: '登录'});
    });

    router.post('/signin', function (req, res, next) {
        userManager.findUser(req.body.username,req.body.password)
        .catch(function (reason) {
            res.render('signin',{title: '登录',error:"错误的用户名或者密码"});
        })
        .then(function (data) {
            if(data[0]) {
                req.session.user=data[1];
                the_user=data[1];
                res.redirect("/detail");
            }else res.render('signin',{title: '登录',error:"错误的用户名或者密码"});
        });
    });

    router.get('/detail', function(req, res, next) {
      if(the_user)req.session.user=the_user;
      req.session.user?res.render('detail', { title: '详情',user:req.session.user }) : res.redirect('/signin');
    });

    router.all('*', function(req, res, next) {
        var username=userManager.parseUsername(req);
        if(username&&req.session.user){
            if(username==req.session.user.username)res.render('detail', { title: '详情',user:req.session.user });
            else res.render('detail', { title: '详情',user:req.session.user ,error:"只能够访问自己的数据"});
        }
        else req.session.user?res.render('detail', { title: '详情',user:req.session.user }) : res.redirect('/signin');
    });

    return router;
};