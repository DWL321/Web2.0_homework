/*19335040 丁维力*/
/*Sign up js文件*/
// 可用node signup.js 启动程序，然后通过浏览器 http://localhost:8000/ 访问
var http = require("http");
var urlTool=require('url');
var querystring=require('querystring');
var jade=require('jade');
var fs = require('fs');
var validator = require('../js/validator');
var users={};
//创建服务，接收请求并做出应答
var server = http.createServer(function(request, response) {
    switch (request.url){
        case '/js/validator.js':
            sendFile(response,'../js/validator.js','text/javascript');
            break;
        case '/js/check.js':
            sendFile(response,'../js/check.js','text/javascript');
            break;
        case '/js/jquery.js':
            sendFile(response,'../js/jquery.js','text/javascript');
            break;
        case '/CSS/signup.css':
            sendFile(response,'../CSS/signup.css','text/css');
            break;
        case '/CSS/detail.css':
            sendFile(response,'../CSS/detail.css','text/css');
            break;
        case '/assest/background1.jpg':
            sendFile(response,'../assest/background1.jpg','image/jpeg');
            break;
        case '/assest/background2.jpg':
            sendFile(response,'../assest/background2.jpg','image/jpeg');
            break;
        default:
            request.method==='POST' ? registUser(request,response):sendHtml(request,response);

        }
});
//发送文件
function sendFile(res,filepath,mime) {
    res.writeHead(200,{"Content-Type":mime});
    res.end(fs.readFileSync(filepath));
}
//注册用户
function registUser(request,response){
    request.on('data',function(chunk){
        try{
            var user=parseUser(chunk.toString());
            checkUser(user);
            users[user.username]=user;
            response.writeHead(301,{Location:'?username='+user.username});
            response.end();
        }catch(error){
            console.warn("regist error:",error);
            showHtml(response,'../jade/signup.jade',{user:user,error:error.message});
        }
    });
}
//服务端检查用户合法性
function checkUser(user){
    var errorMessages=[];
    for(var key in user){
        if(!validator.isFieldValid(key,user[key]))errorMessages.push(validator.form[key].errorMessage);
        if(!validator.isAttrValueUnique(users,user,key))
            errorMessages.push("key:"+key+" is not unique by value:"+user[key]);
    }
    if(errorMessages.length>0)throw new Error(errorMessages.join('<br />'));
}
//分析用户信息
function parseUser(message){
    params=message.match(/username=(.+)&sid=(.+)&phone=(.+)&email=(.+)/);
    var user={username:params[1],sid:params[2],phone:params[3],email:decodeURIComponent(params[4])};
    console.log("user parsed is:",user);
    return user;
}
//选择发送html文件
function sendHtml(request,response){
    var username=parseUsername(request);
    if(!username||!isRegistedUser(username))showHtml(response,'../jade/signup.jade',{username:username,error:null});
    else showHtml(response,'../jade/detail.jade',users[username]);
}
//分析用户名
function parseUsername(request){
    return querystring.parse(urlTool.parse(request.url).query).username;
}
//是否为已注册用户
function isRegistedUser(username){
    return !!users[username];
}
//发送html文件
function showHtml(response,file,data){
    response.writeHead(200,{"Content-Type":"text/html"});
    response.end(jade.renderFile(file,data));
}
server.listen(8000);
console.log("Server is listening");