$(function(){
	$('input:not(.button)').blur(function(){// 检测用户输入的信息是否合法并指出错误
		if(validator.isFieldValid(this.id,$(this).val())){
			$(this).parent().find('.error').text('').hide();
		}else{
			$(this).parent().find('.error').text(validator.form[this.id].errorMessage).show();
		}
	});
	$('.submit').click(function(){//提交信息
		$('input:not(.button)').blur();
		if(!validator.isFieldValid())return false;
	});
	$('input.reset').click(function () {//清除表单内容
        $('input:not(.button)').val('');
        $('.error').text('').hide();
        return false;
    });
});