/*常量区*/
var button_live = [false,false,false,false,false];
var isButtonActive = [false,false,false,false,false];
var info_live = false;
var numButtonActive = 0;
var url = "http://localhost:3000";
var inplace=false;//记录鼠标是否离开@+区域

/*初始化及添加事件监听器*/
$(function () {
    $(".unread").hide();
    $(".unread").text(0);
    $("#button").mouseenter(function () {
        button_live = [true,true,true,true,true];
        inplace=true;
    });
    //点击@+按钮，模拟异步执行按随机序列点击按钮，获取随机数，然后点击大气泡求和的过程
    $(".apb").click(function () {
        var arr = getRandom();
        buttonClick(arr[0]).then(function (value) {
            return buttonClick(arr[1]);
        }).then(function (value) {
            return buttonClick(arr[2]);
        }).then(function (value) {
            return buttonClick(arr[3]);
        }).then(function (value) {
            return buttonClick(arr[4]);
        }).then(function (value) {
            infoClick();
        });
    });
    $("#button").mouseleave(function () {
        leavebutton();
    });
    $("#A").click(function () {
        buttonClick(0);
    });
    $("#B").click(function () {
        buttonClick(1)
    });
    $("#C").click(function () {
        buttonClick(2)
    });
    $("#D").click(function () {
        buttonClick(3)
    });
    $("#E").click(function () {
        buttonClick(4)
    });
    $("#info-bar").click(infoClick);
});
//鼠标离开@+区域，将重置整个计算器，清除所有A~E按钮的随机数和大气泡内的和，离开3秒后鼠标再返回@+区域可以开始新一轮的计算操作
function leavebutton(){
    inplace=false;
    $(".unread").hide();
    $(".unread").text(0);
    $("#queue").hide();
    button_live = [false,false,false,false,false];
    isButtonActive = [false,false,false,false,false];
    info_live = false;
    numButtonActive = 0;
    $("#sum").text("");
    $("#info-bar").css("background-color","rgb(126, 126, 126)");
    $(".button").css("background-color","#2F3BA2");
}
/*获得随机序列*/
function getRandom() {
    var arr = [];
    var temp;
    var alpha = ['A','B','C','D','E'];
    var str = "Queue: ";
    do{
        temp = parseInt(Math.random()*5);
        if(arr.indexOf(temp)===-1) {
            arr[arr.length] = temp;
            if(arr.length===1)
                str+=alpha[temp];
            else
                str+=", "+alpha[temp];
        }
    }while(arr.length!==5);
    $("#queue").show();
    $("#queue").text(str);
    return arr;
}
/*大气泡点击（注意点击大气泡中心）*/
function infoClick() {
    if(info_live){//若大气泡处于激活状态
        var sum = 0;
        for(var k = 0;k<5;k++){//计算结果
            sum+= parseInt($(".unread").eq(k).text());
        }
        $("#sum").text(sum);//显示结果
        info_live = false;//大气泡灭活
        $("#info-bar").css("background-color","rgb(126, 126, 126)");
    }
}
/*小按钮点击*/
function buttonClick(i){
    var p = new Promise(function (resolve,reject) {
        if(button_live[i]){//若此按钮处于激活状态
            button_live[i] = false;//按钮灭活
            if(!isButtonActive[i]) {
                $(".unread").eq(i).show();
                isButtonActive[i] = true;
            }
            $(".unread").eq(i).text("...");//显示等待随机数状态
            setTimeout(function () {
                var j;
                for(j = 0;j<5;j++){//其它按钮灭活
                    if(j!==i) {
                        if(button_live[j]!==false) {
                            button_live[j] = false;
                            $(".button").eq(j).css("background-color","rgb(126, 126, 126)");
                        }
                    }
                }
                /*异步操作*/
                RunButton().then(function (value) {
                    $(".unread").eq(i).text(value);//显示随机数
                    numButtonActive++;
                    $(".button").eq(i).css("background-color","rgb(126, 126, 126)");
                    for(j = 0;j<5;j++){//其它没按过的按钮激活
                        if(j!==i) {
                            if(button_live[j]!==true&&isButtonActive[j]===false) {
                                button_live[j] = true;
                                $(".button").eq(j).css("background-color","#2F3BA2");
                            }
                        }
                    }
                    if(numButtonActive===5){//按钮全部点完激活大气泡
                        info_live = true;
                        $("#info-bar").css("background-color","#2F3BA2");
                    }
                    resolve();
                }).catch(function () {
                    leavebutton();
                });
            },0);
        }
    });
    return p;
}
/*按钮运行*/
function RunButton() {
    var p = new Promise(function (resolve, reject) {
        $.get(url,function (data) {//$.get() 方法使用 HTTP GET 请求从服务器加载随机数。
            if(!inplace)reject();//若鼠标离开@+区域则重置整个计算器
            else resolve(data);//将随机数传给下一个then
        });
    });
    return p;
}